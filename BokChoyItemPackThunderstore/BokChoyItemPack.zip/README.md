This adds 9 new items to the game that reference my vtuber friends (more soon when I fix all the bugs) 

VERY WORK IN PROGRESS DOWNLOAD AT YOUR OWN RISK.
