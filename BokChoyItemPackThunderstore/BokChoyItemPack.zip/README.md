# BokChoyWithSoy's Items

Adds 9 items to the game. These items are based off my vtuber friends and there will be more to come in the future.

Network Compatible (TBD)

Created by BokChoyWithSoy. Help me out for bugs and issues by contacting me on discord: BokChoyWithSoy#3842
  
## Items

<table>
<thead>  
  <tr>
    <td>Items</td>
    <th>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
    <td>Description</td>
  </tr>
  <tr>
    <td>Mask of Plausible Deniability</td>
    <td><img src="https://media.discordapp.net/attachments/399901440023330816/1067797052978888735/Cali.png" alt="Image" width="100" height="100"></td>
    <td>Temporarily increase attack speed by 0.05% (0.05% per stack) each time you attack the same enemy.<br></td>
  </tr>
  <tr>
    <td>Puppy Scarf</td>
    <td><img src="https://media.discordapp.net/attachments/399901440023330816/1067797053469642753/Derrick.png" alt="Image" width="100" height="100"></td>
    <td>Increase base damage by 3 (+3 per stack) and armour by 6 (+6 per stack).<br></td>
  </tr>
  <tr>
    <td>Tie Of The Cursed Bartender</td>
    <td><img src="https://media.discordapp.net/attachments/399901440023330816/1067797053704503427/Jasper.png" alt="Image" width="100" height="100"></td>
    <td>Heal +5% (+5% per stack) more.</td>
  </tr>
  <tr>
    <td>Fox Eyes</td>
    <td><img src="https://media.discordapp.net/attachments/399901440023330816/1067797054480453672/Sol.png" alt="Image" width="100" height="100"></td>
    <td>Activating your Secondary skill also throws an eyeball which explodes, dealing 200% (100% per stack) base damage.</td>
  </tr>
  <tr>
    <td>Digital Devil</td>
    <td><img src="https://media.discordapp.net/attachments/399901440023330816/1067797052723056740/Blue.png" alt="Image" width="100" height="100"></td>
    <td>Killing an enemy increases your movement speed permanently by 0.1% (0.1% per stack), up to 25% (25% per stack).</td>
  </tr>
  <tr>
    <td>Normal Rocks</td>
    <td><img src="https://media.discordapp.net/attachments/399901440023330816/1067797053968764988/Kise.png" alt="Image" width="100" height="100"></td>
    <td>Every 10 seconds, getting hit causes exploding rocks to fall from the sky, dealing 800% damage each. Summons  3 rocks (+2 per stack) with a 10m radius.</td>
  </tr>
  <tr>
    <td>Confused and Crazy</td>
    <td><img src="https://media.discordapp.net/attachments/399901440023330816/1067797053205385247/Confused.png" alt="Image" width="100" height="100"></td>
    <td>Increase the number of interactables per stage by 70% (70% per stack). Increase difficulty scaling by 5% (5% per stack).</td>
  </tr>
  <tr>
    <td>FUCK Hat</td>
    <td><img src="https://media.discordapp.net/attachments/399901440023330816/1067797057030590564/Yihnie.png" alt="Image" width="100" height="100"></td>
    <td>Increase base Damage by 100% (+100% per stack). There is a 20% chance (+5% per stack) this item fucking kills you.</td>
  </tr>
  <tr>
    <td>Luscious Gnome Afro</td>
    <td><img src="https://media.discordapp.net/attachments/399901440023330816/1067797054228791416/Nate.png" alt="Image" width="100" height="100"></td>
    <td>Polymorph into an overloading worm for 20 seconds.</td>
  </tr>
</tbody>
</table>

## Support me on Ko-fi
If you like my stupid mod idea, then consider supporting me on ko-fi! <br>
<a href="https://ko-fi.com/bokchoywithsoy">
<img src="https://media.discordapp.net/attachments/399901440023330816/952862894721208330/download.png"><br>
</a>

## Popcorn Factory

<details>
<summary>Check out other mods from the Popcorn Factory team!</summary>

<div>
    <a href="https://thunderstore.io/package/PopcornFactory/DarthVaderMod/">
      <img width="130" src="https://user-images.githubusercontent.com/93917577/180753359-4906ca0b-6ce5-4ff7-9962-bdec3329682c.png"/>
      <p>Darth Vader Mod (Popcorn Factory)</p>
    </a>
</div>
<div>
    <a href="https://thunderstore.io/package/PopcornFactory/DittoMod/">
        <img src="https://user-images.githubusercontent.com/93917577/168004690-23b6d040-5f89-4b62-916b-c40d774bff02.png"><br>
        <p>DittoMod (TeaL)</p>
    </a>
</div>
<div>
    <a href="https://thunderstore.io/package/PopcornFactory/ShigarakiMod/">
        <img src="https://user-images.githubusercontent.com/93917577/168004591-39480a52-c7fe-4962-997f-cd9460bb4d4a.png"><br>
        <p>ShigarakiMod (TeaL)</p>
    </a>
</div>
<div>
    <a href="https://thunderstore.io/package/TeaL/DekuMod/">
        <img src="https://cdn.discordapp.com/attachments/399901440023330816/960043614036168784/TeaL-DekuMod-3.1.1.png.128x128_q95.png"><br>
        <p>DekuMod (TeaL)</p>
    </a>
</div>
<div>
    <a href="https://thunderstore.io/package/Ethanol10/Ganondorf_Mod/">
        <img src="https://cdn.discordapp.com/attachments/399901440023330816/960043613428011079/Ethanol10-Ganondorf_Mod-2.1.5.png.128x128_q95.png"><br>
        <p>Ganondorf Mod (Ethanol 10)</p>
    </a>
</div>
<div>
    <a href="https://thunderstore.io/package/BokChoyWithSoy/Phoenix_Wright_Mod/">
        <img src="https://cdn.discordapp.com/attachments/399901440023330816/960054458790850570/BokChoyWithSoy-Phoenix_Wright_Mod-1.6.2.png.128x128_q95.png"><br>
        <p>Phoenix Wright Mod (BokChoyWithSoy)</p>
    </a>
</div>
<div>
    <a href="https://thunderstore.io/package/PopcornFactory/Rimuru_Tempest_Mod/">
        <img width="130" src="https://raw.githubusercontent.com/Ethanol10/rimuru-tempest-ror2/master/ReleaseFolder/Icon.png"><br>
        <p>Rimuru Tempest Mod (Popcorn Factory)</p>
    </a>
</div>

</details>

## Changelog

<details open>
  <summary>Click to expand patch notes</summary>

- 1.0.1
	- <Puppy Scarf>
	>+ Base Damage: 1 -> 3
	>+ Armour 2 -> 6

	- <Cursed Bartender's Tie>
	>+ Fixed an issue where healing would be reduced instead of increased

	- <Mask of Plausible Deniability>
	>+ Attack Speed Increase: 0.01 -> 0.05
	>+ Updated description to reflect, EACH time you hit something attack speed increases.

	- <Digital Devil>
	>+ Movement Speed Increase: 0.01 -> 0.1

	- <Confused and Crazy>
	>+ Interactables Increase: 40% -> 70%
	>+ Fixed an issue where interactables would be decreased in instead of increased.
	
- 1.0.0
	- <Puppy Scarf>
	>+ Base Damage: 1% -> 1 flat
	>+ NEW: 2 Armour per stack

	- <Cursed Bartender's Tie>
	>+ Base Healing Percentage: 15% -> 5%
	>+ Fixed Description/Log description

	- Bug Fixes
	>+ Fixed an issue where <Mask of Plausible Deniability> would throw NREs
	>+ Fixed an issue where <Fox Eyes> would throw NREs
	>+ Fixed an issue where <Normal Rocks> would throw NREs

- 0.0.1
	- Initial Release
</details>
 
## Future Plans
- Add more items

## Known Issues
- Digital Devil will give you the same bonus you had before if you scrap it and pick up another one.
- Fox Eyes projectile is way too big.

## Credits
- hex3 - Hex3Mod code
- TheMysticSword - MysticItems code
- Zenithrium - VanillaVoid code